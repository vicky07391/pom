package com.capgemini.barclayscards.poc;

/**
 * @author apatel5
 *
 */
public class TestConsumer {

	/*@Test
	public void contextLoads() {

		String message = EventStoreMessageDeliveryApplicationTests.runConsumer();

		assertNotNull(message);

		System.out.println("Message received from consumer - " + message);
	}*/
}
