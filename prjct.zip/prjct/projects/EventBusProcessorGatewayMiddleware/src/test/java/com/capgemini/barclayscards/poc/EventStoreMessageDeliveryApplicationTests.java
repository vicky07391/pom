package com.capgemini.barclayscards.poc;

import static org.junit.Assert.assertNotNull;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * This test class contains the method to run consumer.
 *
 */
public final class EventStoreMessageDeliveryApplicationTests {

	/**
	 * RESTTemplate instance.
	 */
	private static RestTemplate restTemplate = new RestTemplate();

	/**
	 * Private default constructor.
	 */
	private EventStoreMessageDeliveryApplicationTests() {

	}

	/**
	 * This method will make a REST call to the consumer REST API and will get a
	 * message in response.
	 *
	 * @return message JSON representation for the message.
	 */
	public static String runConsumer() {

		String url = "http://10.217.100.253:5223/consumer/getMessage";

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);

		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, httpEntity, String.class);

		assertNotNull(response);

		return response.getBody();
	}

}
