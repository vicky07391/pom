package com.capgemini.barclayscards.poc;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * Class to test the buffer that we are using to store the consumed messages.
 *
 */
public class TestBufferFlow {

	/**
	 * RESTTemplate instance.
	 */
	private RestTemplate restTemplate = new RestTemplate();

	/**
	 * Variable which defines the value for which the thread will sleep before
	 * invoking call to consumer.
	 */
	private long sleepTime = 2000;

	/**
	 * Method to start the test.
	 *
	 * @throws InterruptedException
	 *             since we are calling thread.sleep hence this exception may
	 *             occur.
	 */
	@Test
	public void contextLoads() throws InterruptedException {

		List<String> messages = new ArrayList<String>();

		for (int i = 0; i < 15; i++) {

			messages.add(runCustomerCreateProducer());
		}

		Thread.sleep(sleepTime);

		for (int i = 0; i < 15; i++) {

			messages.remove(EventStoreMessageDeliveryApplicationTests.runConsumer());
		}

		assertEquals(messages.size(), 0);
	}

	/**
	 * This method will make a REST call to producer API.
	 *
	 * @return message JSON string representation of the message.
	 */
	private String runCustomerCreateProducer() {

		String url = "http://10.217.100.253:5223/producer/runCustomerCreate";

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);

		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, httpEntity, String.class);

		if (response != null) {

			return response.getBody();
		}

		return "";
	}
}