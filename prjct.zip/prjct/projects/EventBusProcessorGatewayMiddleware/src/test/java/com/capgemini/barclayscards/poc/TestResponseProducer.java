package com.capgemini.barclayscards.poc;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.barclayscard.beans.CustomerResponseDest;
import com.barclayscard.util.JSONUtil;

/**
 * This class will test the flow of response from agnostic layer.
 *
 */
public class TestResponseProducer {

	/**
	 * RESTTemplate instance.
	 */
	private RestTemplate restTemplate = new RestTemplate();

	/**
	 * Method to start the test.
	 *
	 */
	@Test
	public void contextLoads() {

		CustomerResponseDest customerResponseDest = new CustomerResponseDest("none", "success", "TCP", "123",
				"com.barclayscard.customer.events.CustomerAddedEvent");

		String url = "http://localhost:5223/consumer/response";

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<CustomerResponseDest> requestEntity = new HttpEntity<CustomerResponseDest>(customerResponseDest);

		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);

		assertNotNull(response.getBody());

		assertEquals(JSONUtil.convertObjectToJSON(customerResponseDest), response.getBody());

		System.out.println(response.getBody());
	}
}
