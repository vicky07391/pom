package com.capgemini.barclayscards.poc;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * @author apatel5
 *
 */
public class TestAddressUpdate {

	/**
	 * RESTTemplate instance.
	 */
	private RestTemplate restTemplate = new RestTemplate();

	/**
	 * Variable which defines the value for which the thread will sleep before
	 * invoking call to consumer.
	 */
	private long sleepTime = 2000;

	/**
	 * Method to start the test.
	 *
	 * @throws InterruptedException
	 *             since we are calling thread.sleep hence this exception may
	 *             occur.
	 */
	@Test
	public void contextLoads() throws InterruptedException {

		String producedString = runAddressUpdateProducer();

		Thread.sleep(sleepTime);

		String consumedString = EventStoreMessageDeliveryApplicationTests.runConsumer();

		assertEquals(producedString, consumedString);
	}

	/**
	 * This method will make a REST call to the producer API to invoke producer.
	 *
	 * @return message JSON string for the message written on queue.
	 */
	private String runAddressUpdateProducer() {

		String url = "http://10.217.100.253:5223/producer/runAddressUpdate";

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);

		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, httpEntity, String.class);

		if (response != null) {

			return response.getBody();
		}

		return "";
	}
}
