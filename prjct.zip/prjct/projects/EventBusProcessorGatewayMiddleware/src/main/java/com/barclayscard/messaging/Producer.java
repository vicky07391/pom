package com.barclayscard.messaging;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.barclayscard.beans.CustomerResponseDest;
import com.barclayscard.util.JSONUtil;

/**
 * This class is for testing purpose only. This class acts as the Message
 * Producer for the EventBus queue.
 *
 */
@Component
public class Producer {

	/**
	 * Logger instance.
	 */
	private static final Logger LOG = LoggerFactory.getLogger(Producer.class);

	/**
	 * Variable to store the name of queue from which agnostic layer will
	 * consume.
	 */
	@Value("${spring.application.queue}")
	private String queueName;

	/**
	 * Variable to store the name of exchange on which domain services are
	 * writing messages.
	 */
	@Value("${spring.application.exchange}")
	private String exchangeName;

	/**
	 * Variable to store the name of queue on which agnostic layer will write
	 * responses.
	 */
	@Value("${spring.application.responseQueue}")
	private String responseQueueName;

	/**
	 * Variable to store the name of exchange on which agnostic layer will write
	 * messages.
	 */
	@Value("${spring.application.responseExchange}")
	private String responseExchangeName;

	/**
	 * Autowired instance of RabbitMQTemplate through which all the operations
	 * on RabbitMQ queue will be performed.
	 */
	@Autowired
	private RabbitTemplate rabbitTemplate;

	/**
	 * Method to write the JSON string message in the RabbitMQ queue.
	 *
	 * @param message
	 *            the input {@link String}
	 * @return {@link String} JSON message which is written on RabbitMQ queue
	 * @throws IOException
	 */
	public String produce(Object message) {

		LOG.debug("Sending message {} in queue", message);

		rabbitTemplate.convertAndSend(exchangeName, "",
				("com.barclayscard.customer.events.CustomerAddedEvent " + JSONUtil.convertObjectToJSON(message))
						.getBytes());

		return JSONUtil.convertObjectToJSON(message);
	}

	/**
	 * This method will write the response received from the agnostic layer on
	 * to the response queue in EventBus.
	 *
	 * @param customerResponseDest
	 *            the response received from agnostic layer.
	 * @return json JSON string representation of the object written on the
	 *         EventBus response queue.
	 */
	public String writeResponse(CustomerResponseDest customerResponseDest) {

		String message = JSONUtil.convertObjectToJSON(customerResponseDest);

		LOG.debug("Sending message {} in response queue", message);

		rabbitTemplate.convertAndSend(responseExchangeName, "", message);

		LOG.debug("Successfully written message in response queue.");

		return message;
	}

}