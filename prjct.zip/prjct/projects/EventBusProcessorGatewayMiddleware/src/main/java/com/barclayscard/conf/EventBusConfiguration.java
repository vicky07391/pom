package com.barclayscard.conf;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.backoff.ExponentialBackOff;

import com.barclayscard.messaging.Receiver;

/**
 * This class defines all the beans for configuring the connection to EventBUS.
 *
 */
@Configuration
public class EventBusConfiguration {

	/**
	 * Logger instance.
	 */
	private static final Logger LOG = LoggerFactory.getLogger(EventBusConfiguration.class);

	/**
	 * Variable containing the value of host for EventBus.
	 */
	@Value("${spring.eventbus.addresses}")
	private String eventBusAddress;

	/**
	 * EventBus Username.
	 */
	@Value("${spring.eventbus.username}")
	private String username;

	/**
	 * EventBus Password.
	 */
	@Value("${spring.eventbus.password}")
	private String password;

	/**
	 * Variable to store the name of queue from which agnostic layer will
	 * consume.
	 */
	@Value("${spring.application.queue}")
	private String queueName;

	/**
	 * Variable to store the name of exchange on which domain services are
	 * writing messages.
	 */
	@Value("${spring.application.exchange}")
	private String exchangeName;

	/**
	 * Variable to store the name of queue on which agnostic layer will write
	 * responses.
	 */
	@Value("${spring.application.responseQueue}")
	private String responseQueueName;

	/**
	 * Variable to store the name of exchange on which agnostic layer will write
	 * messages.
	 */
	@Value("${spring.application.responseExchange}")
	private String responseExchangeName;

	/**
	 * Variable to store the time in milliseconds for which connection will wait
	 * before retrying.
	 */
	@Value("${spring.application.queueRetry.initialInterval}")
	private Integer queueRetryInitialInterval;

	/**
	 * Variable to store a number by which above interval will be multiplied and
	 * connection will wait for that many milliseconds before retrying.
	 */
	@Value("${spring.application.queueRetry.multiplier}")
	private Integer queueRetryMultiplier;

	/**
	 * @return queue instance of queue from which consumer will consume.
	 */
	@Bean
	Queue consumerQueue() {

		LOG.debug("Initializing queue object in bean method");

		return new Queue(queueName, true);
	}

	/**
	 * @return queue instance of queue on which producer will write messages.
	 */
	@Bean
	Queue responseQueue() {

		LOG.debug("Initializing response queue object in bean method");

		return new Queue(responseQueueName, true);
	}

	/**
	 * @return FanoutExchange instance of exchange for consuming the messages.
	 */
	@Bean
	FanoutExchange consumerExchange() {

		LOG.debug("Initializing FanoutExchange in bean method");

		return new FanoutExchange(exchangeName, true, false); // spring-boot-exchange
	}

	/**
	 * @return FanoutExchange instance of exchange for writing the messages.
	 */
	@Bean
	FanoutExchange responseExchange() {

		LOG.debug("Initializing FanoutExchange in bean method");

		return new FanoutExchange(responseExchangeName, true, false); // spring-boot-exchange
	}

	/**
	 * @return Binding instance of binding of queue and exchange for consumer.
	 */
	@Bean
	Binding consumerBinding() {

		LOG.debug("Initializing binding in bean method");

		return new Binding(queueName, Binding.DestinationType.QUEUE, exchangeName, "*.*", null);
	}

	/**
	 * @return Binding instance of binding of queue and exchange for producer.
	 */
	@Bean
	Binding responseBinding() {

		LOG.debug("Initializing response binding in bean method");

		return new Binding(responseQueueName, Binding.DestinationType.QUEUE, responseExchangeName, "*.*", null);
	}

	/**
	 * @return CachingConnectionFactory instance of connection factory.
	 */
	@Bean
	public ConnectionFactory connectionFactory() {

		LOG.debug("Initializing ConnectionFactory object in bean method");

		CachingConnectionFactory connectionFactory = new CachingConnectionFactory(eventBusAddress);
		connectionFactory.setPublisherConfirms(true);
		connectionFactory.setUsername(username);
		connectionFactory.setPassword(password);

		return connectionFactory;
	}

	/**
	 * @param consumerListenerAdapter
	 *            instance of {@link MessageListenerAdapter}
	 * @return SimpleMessageListenerContainer the container which will
	 *         initialize listener
	 */
	@Bean
	SimpleMessageListenerContainer consumerContainer(
			@Qualifier("consumerListenerAdapter") MessageListenerAdapter consumerListenerAdapter) {

		LOG.debug("Initializing SimpleMessageListenerContainer object in bean method");

		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory());
		container.setQueueNames(queueName);
		container.setMessageListener(consumerListenerAdapter);
		container.setRecoveryBackOff(new ExponentialBackOff(queueRetryInitialInterval, queueRetryMultiplier));
		return container;
	}

	/**
	 * @param receiver
	 *            instance of the class which contains the method to handle
	 *            message.
	 * @return MessageListenerAdapter
	 */
	@Bean
	MessageListenerAdapter consumerListenerAdapter(Receiver receiver) {

		LOG.debug("Initializing listener adapter in bean method");

		return new MessageListenerAdapter(receiver, "handleMessage");
	}

	/*
	 * @Bean SimpleMessageListenerContainer receiverContainer(
	 *
	 * @Qualifier("receiverListenerAdapter") MessageListenerAdapter
	 * receiverListenerAdapter) {
	 *
	 * LOG.
	 * debug("Initializing SimpleMessageListenerContainer object in bean method"
	 * );
	 *
	 * SimpleMessageListenerContainer container = new
	 * SimpleMessageListenerContainer();
	 * container.setConnectionFactory(connectionFactory());
	 * container.setQueueNames(RESPONSE_QUEUE_NAME);
	 * container.setMessageListener(receiverListenerAdapter);
	 * container.setRecoveryBackOff(new ExponentialBackOff(1000, 1)); return
	 * container; }
	 *
	 * @Bean MessageListenerAdapter receiverListenerAdapter(ResponseReceiver
	 * responseReceiver) {
	 *
	 * LOG.debug("Initializing listener adapter in bean method");
	 *
	 * return new MessageListenerAdapter(responseReceiver, "handleMessage"); }
	 */
}
