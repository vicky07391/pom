package com.barclayscard.beans;

import java.io.Serializable;
import java.util.UUID;

/**
 * This abstract class contains the correlation id field.
 *
 */
public abstract class AbstractEvent implements Serializable {

	/**
	 * Base class for all events.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The correlation id which acts as common id between different systems.
	 */
	private UUID correlationID;

	/**
	 * Default constructor.
	 */
	public AbstractEvent() {

	}

	/**
	 * Constructor with correlation id as argument.
	 *
	 * @param correlationID
	 *            the parameter of id.
	 */
	public AbstractEvent(UUID correlationID) {

		this.correlationID = correlationID;
	}

	/**
	 * @return the id
	 */
	public UUID getCorrelationID() {
		return correlationID;
	}
}