package com.barclayscard.beans;

import java.util.UUID;

/**
 * This is the event class for updation of mobile number of customer.
 */
public class MobileNumberUpdatedEvent extends AbstractEvent {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Variable to store mobile number which is to be updated.
	 */
	private String mobileNumber;

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * Default constructor.
	 */
	public MobileNumberUpdatedEvent() {

	}

	/**
	 * @param correlationID
	 *            the id which is used to identify customer across system.
	 * @param mobileNumber
	 *            new mobile number which is to be updated
	 */
	public MobileNumberUpdatedEvent(UUID correlationID, String mobileNumber) {
		super(correlationID);
		this.mobileNumber = mobileNumber;
	}

}
