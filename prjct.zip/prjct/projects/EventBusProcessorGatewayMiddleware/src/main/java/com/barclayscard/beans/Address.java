package com.barclayscard.beans;

import java.io.Serializable;

/**
 * This class is treated as an value object for customer aggregate root.
 *
 */
public class Address implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Variable to store the value of building name.
	 */
	private String buildingName;

	/**
	 * Variable to store the value of street name.
	 */
	private String streetName;

	/**
	 * Variable to store the value of pincode.
	 */
	private String pincode;

	/**
	 * Default constructor.
	 */
	public Address() {

	}

	/**
	 * @param buildingName
	 *            name of the building
	 * @param streetName
	 *            name of the street
	 * @param pincode
	 *            pin code of address
	 */
	public Address(String buildingName, String streetName, String pincode) {
		super();
		this.buildingName = buildingName;
		this.streetName = streetName;
		this.pincode = pincode;
	}

	/**
	 * @return the buildingName
	 */
	public String getBuildingName() {
		return buildingName;
	}

	/**
	 * @return the streetName
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Address [buildingName=" + buildingName + ", streetName=" + streetName + ", pincode=" + pincode + "]";
	}

}
