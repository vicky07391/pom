package com.barclayscard.messaging;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * This class is the RabbitMQ Message Listener and contains method to receive
 * and handle messages from RabbitMQ Queue.
 *
 */
@Component
public class Receiver {

	/**
	 * Logger instance.
	 */
	private static final Logger LOG = LoggerFactory.getLogger(Receiver.class);

	/**
	 * Instance of latch to wait before listening to queue for messages.
	 */
	private CountDownLatch latch = new CountDownLatch(0);

	/**
	 * This method is invoked automatically by MessageListener whenever there is
	 * new message in the queue. Then this method simply adds the received
	 * message in BlockingQueue, if there is space, otherwise waits till space
	 * is available.
	 *
	 * @param message
	 *            the message received from RabbitMQ queue
	 * @throws IOException
	 *             this exception may occur while byte array stream of object
	 * @throws ClassNotFoundException
	 *             this exception is thrown when the parsing is not successful
	 */
	public void handleMessage(Object message) throws IOException, ClassNotFoundException {

		try {

			LOG.debug("Received message in RabbitMQ Receiver.handleMessage() method.");

			String mesg = new String((byte[]) message, "UTF-8"); //

			LOG.debug("Message received - {}", mesg);

			String jsonString = getJSONStringFromMessage(mesg);

			LOG.debug("Extracted JSON string {}", jsonString);

			if (jsonString != null) {

				Buffer.messages.put(jsonString);
			}

			LOG.debug("Added message in in-memory buffer - {}", mesg);

		} catch (final InterruptedException e) {

			LOG.warn("In-memory buffer is full... waiting for space availability");
		}

		latch.countDown();
	}

	/**
	 * Method to return the latch.
	 *
	 * @return latch
	 */
	public CountDownLatch getLatch() {

		return latch;
	}

	/**
	 * This method will extract the JSON message from the incoming byte array
	 * message from RabbitMQ.
	 * 
	 * @param message
	 *            the converted message from RabbitMQ
	 * @return JsonMessage extracted JSON string.
	 */
	private String getJSONStringFromMessage(String message) {

		String eventType = getEventType(message);

		String jsonString = matchNestedPattern(message);

		if (jsonString != null) {

			jsonString = jsonString.substring(0, jsonString.length() - 1) + ",\"eventType\":\"" + eventType + "\"}";

			return jsonString;
		}

		jsonString = matchSimplePattern(message);

		if (jsonString != null) {

			jsonString = jsonString.substring(0, jsonString.length() - 1) + ",\"eventType\":\"" + eventType + "\"}";

			return jsonString;
		}

		return null;
	}

	private static String getEventType(String message) {

		String re1 = "(com)"; // Word 1
		String re2 = "(\\.)"; // Any Single Character 1
		String re3 = "(barclayscard)"; // Word 2
		String re4 = "(\\.)"; // Any Single Character 2
		String re5 = "(customer)"; // Word 3
		String re6 = "(\\.)"; // Any Single Character 3
		String re7 = "(events)"; // Word 4
		String re8 = "(\\.)"; // Any Single Character 4
		String re9 = "((?:[a-z][a-z]+))"; // Word 5

		Pattern p = Pattern.compile(re1 + re2 + re3 + re4 + re5 + re6 + re7 + re8 + re9,
				Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
		Matcher m = p.matcher(message);
		if (m.find()) {
			String word1 = m.group(1);
			String c1 = m.group(2);
			String word2 = m.group(3);
			String c2 = m.group(4);
			String word3 = m.group(5);
			String c3 = m.group(6);
			String word4 = m.group(7);
			String c4 = m.group(8);
			String word5 = m.group(9);
			return (word1.toString() + c1.toString() + word2.toString() + c2.toString() + word3.toString()
					+ c3.toString() + word4.toString() + c4.toString() + word5.toString());
		}

		return null;
	}

	private static Pattern getSimplePattern() {

		String re1 = "(\\{)"; // Any Single Character 1
		String re8 = "(.*?)"; // Double Quote String 4
		String re9 = "(\\})"; // Any Single Character 4

		Pattern p = Pattern.compile(re1 + re8 + re9, Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

		return p;
	}

	private static Pattern getNestedPattern() {

		String re1 = "(\\{)"; // Any Single Character 1
		String re2 = "(.*?)"; // Non-greedy match on filler
		String re3 = "(\\{)"; // Any Single Character 5
		String re4 = "(.*?)"; // Any Single Character 6
		String re5 = "(\\})"; // Any Single Character 7
		String re6 = "(.*?)"; // Any Single Character 6
		String re7 = "(\\})"; // Any Single Character 11

		Pattern p = Pattern.compile(re1 + re2 + re3 + re4 + re5 + re6 + re7, Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

		return p;
	}

	private String matchSimplePattern(String message) {

		Pattern simplePattern = getSimplePattern();

		Matcher simpleMatcher = simplePattern.matcher(message);

		if (simpleMatcher.find()) {

			String c1 = simpleMatcher.group(1);
			String string1 = simpleMatcher.group(2);
			String c2 = simpleMatcher.group(3);
			return (c1.toString() + string1.toString() + c2.toString());
		}

		return null;
	}

	private String matchNestedPattern(String message) {

		Pattern nestedPattern = getNestedPattern();

		Matcher nestedMatcher = nestedPattern.matcher(message);

		if (nestedMatcher.find()) {

			String c1 = nestedMatcher.group(1);
			String word1 = nestedMatcher.group(2);
			String c2 = nestedMatcher.group(3);
			String word2 = nestedMatcher.group(4);
			String c3 = nestedMatcher.group(5);
			String word3 = nestedMatcher.group(6);
			String c4 = nestedMatcher.group(7);
			return (c1.toString() + word1.toString() + c2.toString() + word2.toString() + c3.toString()
					+ word3.toString() + c4.toString());
		}

		return null;
	}
}