package com.barclayscard.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.barclayscard.messaging.Receiver;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Utility class to convert any {@link Object} into a JSON string
 * representation. This class uses com.fasterxml.jackson library for the
 * conversion
 *
 */
public final class JSONUtil {

	/**
	 * Logger instance.
	 */
	private static final Logger LOG = LoggerFactory.getLogger(Receiver.class);

	/**
	 * Private Default constructor.
	 *
	 */
	private JSONUtil() {

	}

	/**
	 * Method to convert an {@link Object} into JSON String.
	 *
	 * @param object
	 *            the input object which can be anything, even {@link Map}
	 * @return {@link String} JSON representation of object
	 */
	public static String convertObjectToJSON(Object object) {

		LOG.debug("Coverting object {} in JSON string in JSONUtil.convertObjectToJSON() method", object);

		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = "";

		try {

			jsonInString = mapper.writeValueAsString(object);

		} catch (final JsonProcessingException e) {

			LOG.error("Exception occured while converting object into JSON string, please check logs", e);
		}

		return jsonInString;
	}
}
