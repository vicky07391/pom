/**
 * This package will contain all the utility classes.
 */
package com.barclayscard.util;