/**
 * This package contains all the bean classes used in the project.
 *
 */
package com.barclayscard.beans;