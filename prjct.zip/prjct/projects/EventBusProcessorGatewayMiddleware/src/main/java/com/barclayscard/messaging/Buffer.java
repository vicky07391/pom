package com.barclayscard.messaging;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * This class has a {@link BlockingQueue} with a specific size. This size will
 * be dynamic from configuration. This {@link BlockingQueue} acts as a buffer
 * between the RabbitMQ Message Listener and the Camel Consumer
 *
 */
@Component
public class Buffer {

	/**
	 * Variable to store the value of the capacity of the blocking queue.
	 */
	@Value("${spring.application.buffer.size}")
	private Integer bufferSize;

	/**
	 * Variable which will act as buffer between the consumer and the REST
	 * controller.
	 */
	public static BlockingQueue<String> messages;

	/**
	 * This method will be automatically called when all the dependencies are
	 * autowired. This method will initialize the buffer.
	 */
	@PostConstruct
	public void initBuffer() {

		messages = new ArrayBlockingQueue<String>(bufferSize, true);
	}
}