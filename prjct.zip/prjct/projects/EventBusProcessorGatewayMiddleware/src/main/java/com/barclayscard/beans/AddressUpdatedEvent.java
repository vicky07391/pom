package com.barclayscard.beans;

import java.util.UUID;

/**
 * This is the event class for updation of address of customer.
 */
public class AddressUpdatedEvent extends AbstractEvent {

	private static final long serialVersionUID = 1L;
	/**
	 * Variable to store object of {@link Address}.
	 */
	private final Address address;

	/**
	 * Constructor to create object of {@link Address} with correlation id and
	 * address object.
	 *
	 * @param correlationID
	 *            the correlation id which is same across the systems.
	 * @param address
	 *            the new address object which is to be updated.
	 */
	public AddressUpdatedEvent(UUID correlationID, Address address) {
		super(correlationID);
		this.address = address;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}
}