/**
 * This package will contain event bus configuration.
 */
package com.barclayscard.conf;