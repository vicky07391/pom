package com.barclayscard.beans;

import java.util.UUID;

/**
 * This is the event class for updation of email address of customer.
 */
public class EmailAddressUpdatedEvent extends AbstractEvent {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Variable to store the new email address which is to be stored.
	 */
	private String emailAddress;

	/**
	 * Default constructor.
	 */
	public EmailAddressUpdatedEvent() {

	}

	/**
	 * @param correlationID
	 *            the id which is used to identify customer across system.
	 * @param emailAddress
	 *            new email address which is to be updated
	 */
	public EmailAddressUpdatedEvent(UUID correlationID, String emailAddress) {
		super(correlationID);
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
}
