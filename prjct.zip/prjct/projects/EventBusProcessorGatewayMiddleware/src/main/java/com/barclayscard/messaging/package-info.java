/**
 * This package will contain all the classes related to the messaging.
 */
package com.barclayscard.messaging;