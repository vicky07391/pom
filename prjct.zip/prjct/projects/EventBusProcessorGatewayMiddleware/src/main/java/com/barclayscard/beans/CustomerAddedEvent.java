package com.barclayscard.beans;

import java.util.Date;
import java.util.UUID;

/**
 * This is the event class for creation of customer.
 */
public class CustomerAddedEvent extends AbstractEvent {

	/**
	*
	*/
	private static final long serialVersionUID = 1L;

	/**
	 * Variable to store first name of the customer.
	 */
	private String firstName;

	/**
	 * Variable to store last name of the customer.
	 */
	private String lastName;

	/**
	 * Variable to store mobile number of the customer.
	 */
	private String mobileNumber;

	/**
	 * Variable to store email address of the customer.
	 */
	private String emailAddress;

	/**
	 * Variable to store address of the customer.
	 */
	private Address address;

	/**
	 * Variable to store date of birth of the customer.
	 */
	private Date dob;

	/**
	 * Variable to store mobile number of the customer.
	 */
	private String sourceIdentifier;

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * @return dob
	 */
	public Date getDob() {
		return dob;
	}

	/**
	 * @return source identifier
	 */
	public String getSourceIdentifier() {
		return sourceIdentifier;
	}

	/**
	 * Default constructor.
	 */
	public CustomerAddedEvent() {

	}

	/**
	 * @param correlationID
	 *            the correlation id which is same across the systems
	 * @param firstName
	 *            first name of the customer
	 * @param lastName
	 *            last name of the customer
	 * @param mobileNumber
	 *            mobile number of the customer
	 * @param emailAddress
	 *            email address of the customer
	 * @param address
	 *            address of the customer
	 * @param dob
	 *            date of birth of the customer
	 * @param sourceIdentifier
	 *            source identifier for the routing of message to destination
	 */
	public CustomerAddedEvent(UUID correlationID, String firstName, String lastName, String mobileNumber,
			String emailAddress, Address address, Date dob, String sourceIdentifier) {
		super(correlationID);
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.emailAddress = emailAddress;
		this.address = address;
		this.dob = dob;
		this.sourceIdentifier = sourceIdentifier;
	}
}