package com.barclayscard.eventbus.configuration;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Spring Boot Application class. */
@SpringBootApplication
public class EventBusApplication {

  /**
   * Application Main Method.
   * @param args argument
   */
	public static void main(String[] args) {
		SpringApplication.run(EventBusApplication.class, args);
	}
}
