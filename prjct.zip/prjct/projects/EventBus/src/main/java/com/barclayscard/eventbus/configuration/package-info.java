
/**
 * @author Capgemini
 *
 */
package com.barclayscard.eventbus.configuration;