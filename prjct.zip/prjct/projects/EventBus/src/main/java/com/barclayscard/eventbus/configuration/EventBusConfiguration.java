package com.barclayscard.eventbus.configuration;


import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.transaction.RabbitTransactionManager;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Event bus configuration : {Messaging Queue}.
 */
@Configuration
@EnableAutoConfiguration 
public class EventBusConfiguration {

  /** The actual value expression of eventbus hostname : {applicationProperties.spring.queue.hostname. */
  @Value("${spring.queue.hostname}")
  private String hostname;

  /** The actual value expression of eventbus username : {applicationProperties.spring.queue.username. */
  @Value("${spring.queue.username}")
  private String username;

  /** The actual value expression of eventbus password : {applicationProperties.spring.queue.password. */
  @Value("${spring.queue.password}")
  private String password;

  /** The actual value expression of exchange : {applicationProperties.spring.application.exchange. */
  @Value("${spring.application.exchange}")
  private String exchangeName;

  /** The actual value expression of queue name : {applicationProperties.spring.application.queue. */
  @Value("${spring.application.queue}")
  private String queueName;
  

  /** The actual value expression of queue name : {applicationProperties.spring.application.queue. */
  @Value("${spring.application.responsequeue}")
  private String responsQueueName;
  

  /** Construct a new queue, given a name and durability flag.
   * @return queue*/
  @Bean
  Queue defaultStream() {
    return new Queue(queueName, true);
  }


  /** Construct a new queue, given a name and durability flag.
   * @return queue*/
  @Bean
  Queue defaultStreamForResponse() {
    return new Queue(responsQueueName, true);
  }
  
  /**
   * Simple container collecting information to describe a fanout exchange : {name, durable, autodelete }.
   * @return FanoutExchange
   */
  @Bean
  FanoutExchange eventBusExchange() {
    return new FanoutExchange(exchangeName, true, false);
  }

 
  /**
  * Simple container collecting information to describe a binding. Takes String destination
  * and exchange names as arguments to facilitate wiring using code based configuration.
   * @return Binding
   */
  @Bean
  Binding binding() {
    return new Binding(queueName, Binding.DestinationType.QUEUE, exchangeName, "*.*", null);
  }
  
  
  /**
  * Simple container collecting information to describe a binding. Takes String destination
  * and exchange names as arguments to facilitate wiring using code based configuration.
   * @return Binding
   */
  @Bean
  Binding bindingForResponse() {
    return new Binding(responsQueueName, Binding.DestinationType.QUEUE, exchangeName, "*.*", null);
  }
/**
 * An interface based ConnectionFactory for creating Connections.
 * @return ConnectionFactory
 */
  @Bean
  ConnectionFactory connectionFactory() {
    CachingConnectionFactory connectionFactory = null;
    try {
      connectionFactory = new CachingConnectionFactory(hostname);
      connectionFactory.setUsername(username);
      connectionFactory.setPassword(password);
      return connectionFactory;
    } catch (final Exception e) {

    }
    return connectionFactory;
  }


  /**
   * RabbitMQ implementation of portable AMQP administrative operations for AMQP.
   * @return RabbitAdmin
   */
  @Bean
  @Required
  RabbitAdmin rabbitAdmin() {
    RabbitAdmin admin = null;
    try {
      admin = new RabbitAdmin(connectionFactory());
      admin.setAutoStartup(true);
      admin.declareExchange(eventBusExchange());
      admin.declareQueue(defaultStream());
      admin.declareBinding(binding());
      
      admin.declareExchange(eventBusExchange());
      admin.declareQueue(defaultStreamForResponse());
      admin.declareBinding(bindingForResponse());
      return admin;
    } catch (final Exception e) {
    }
    return admin;
  }
  
 
/**
 * Create a new RabbitTransactionManager for bean-style usage.
 * @return RabbitTransactionManager
 */
  @Bean
  RabbitTransactionManager rabbitTransactionManager() {
      RabbitTransactionManager txMgr = new RabbitTransactionManager(connectionFactory());
      
      return txMgr;
  }

  
 

}
