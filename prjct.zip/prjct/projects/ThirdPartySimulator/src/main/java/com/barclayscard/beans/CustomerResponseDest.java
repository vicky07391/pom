package com.barclayscard.beans;

import java.io.Serializable;
import java.util.UUID;

/**
 * Customer data POJO for Response.
 *
 */
public class CustomerResponseDest implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * Variable to store success message from agnostic layer.
	 */
	private String successMessage;

	/**
	 * Variable to store error code from agnostic layer.
	 */
	private String errorCode;

	/**
	 * Variable to store source identifier from agnostic layer.
	 */
	private String sourceIdentifier;

	/**
	 * Variable to store correlation id from agnostic layer.
	 */
	private UUID correlationID;

	/**
	 * @return error code if any.
	 */
	public String getErrorCode() {

		return errorCode;
	}

	/**
	 * @param errorCode
	 *            setter to set value of error code.
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return successMessage
	 */
	public String getSuccessMessage() {
		return successMessage;
	}

	/**
	 * @param successMessage
	 *            setter for setting the value of successMessage
	 */
	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	/**
	 * @return sourceIdentifier
	 */
	public String getSourceIdentifier() {
		return sourceIdentifier;
	}

	/**
	 * @param sourceIdentifier
	 *            setter for setting value of sourceIdentifier
	 */
	public void setSourceIdentifier(String sourceIdentifier) {
		this.sourceIdentifier = sourceIdentifier;
	}

	/**
	 * @return correlationId
	 */
	public UUID getCorrelationID() {
		return correlationID;
	}

	/**
	 * @param correlationID
	 *            setter for setting the value of correlationId
	 */
	public void setCorrelationID(UUID correlationID) {
		this.correlationID = correlationID;
	}

	/**
	 * @param errorCode
	 *            error code from agnostic layer
	 * @param successMessage
	 *            success message from agnostic layer
	 * @param sourceIdentifier
	 *            source identifier from agnostic layer
	 * @param correlationID
	 *            correlationId from agnostic layer
	 */
	public CustomerResponseDest(String errorCode, String successMessage, String sourceIdentifier, UUID correlationID) {
		super();
		this.errorCode = errorCode;
		this.successMessage = successMessage;
		this.sourceIdentifier = sourceIdentifier;
		this.correlationID = correlationID;
	}

	/**
	 * Default constructor.
	 */
	public CustomerResponseDest() {

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return successMessage + "" + errorCode + "" + sourceIdentifier + "" + correlationID;
	}

}
