/**
 * This package will contain all the configuration classes.
 */
package com.barclayscard.conf;