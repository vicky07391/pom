package com.barclayscard.messaging;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * This class is the RabbitMQ Message Listener and contains method to receive
 * and handle messages from RabbitMQ Queue.
 *
 */
@Component
public class Receiver {

	/**
	 * Logger instance.
	 */
	private static final Logger LOG = LoggerFactory.getLogger(Receiver.class);

	/**
	 * Instance of latch to wait before listening to queue for messages.
	 */
	private CountDownLatch latch = new CountDownLatch(0);

	/**
	 * Variable to store the name of queue on which agnostic layer will write
	 * responses.
	 */
	@Value("${spring.application.responseQueue}")
	private String responseQueueName;

	/**
	 * Variable to store the name of exchange on which agnostic layer will write
	 * messages.
	 */
	@Value("${spring.application.responseExchange}")
	private String responseExchangeName;

	/**
	 * Autowired instance of RabbitMQTemplate through which all the operations
	 * on RabbitMQ queue will be performed.
	 */
	@Autowired
	private RabbitTemplate rabbitTemplate;

	/**
	 * This method is invoked automatically by MessageListener whenever there is
	 * new message in the queue. Then this method simply adds the received
	 * message in BlockingQueue, if there is space, otherwise waits till space
	 * is available.
	 *
	 * @param message
	 *            the message received from RabbitMQ queue
	 * @throws IOException
	 *             this exception may occur while byte array stream of object
	 * @throws ClassNotFoundException
	 *             this exception is thrown when the
	 */
	public void handleMessage(byte[] message) throws IOException, ClassNotFoundException {

		// System.out.println(new String(message, "UTF-8"));

		String m = new String(message, "UTF-8");

		try {

			LOG.debug("Received message in RabbitMQ Receiver.handleMessage() method. {}", message);

			String id = m.substring(0, 36).trim();
			String sourceIdenifier = m.substring(301, 316).trim();
			String eventType = m.substring(316).trim();

			LOG.debug("Substring are - {} {} {}", id, sourceIdenifier, eventType);

			String responseMessage = fixedLengthString("0000", "success", sourceIdenifier, id, eventType);

			LOG.debug("Writing message on response queue - {}", responseMessage);

			rabbitTemplate.convertAndSend(responseExchangeName, "", responseMessage);

		} catch (Exception e) {

			LOG.warn("Exception while while parsing received message", e);
		}

		latch.countDown();
	}

	public CountDownLatch getLatch() {

		return latch;
	}

	public static String fixedLengthString(String errorCode, String success, String sourceIdentifier,
			String correlationID, String eventType) {

		errorCode = String.format("%1$" + 4 + "s", errorCode);
		success = String.format("%1$" + 7 + "s", success);
		sourceIdentifier = String.format("%1$" + 15 + "s", sourceIdentifier);
		correlationID = String.format("%1$" + 36 + "s", correlationID);
		eventType = String.format("%1$" + 128 + "s", eventType);

		return success + errorCode + sourceIdentifier + correlationID + eventType;
	}
}