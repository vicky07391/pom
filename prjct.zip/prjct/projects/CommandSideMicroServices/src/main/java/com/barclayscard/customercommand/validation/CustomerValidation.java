package com.barclayscard.customercommand.validation;

import java.util.Calendar;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.barclayscard.customer.exception.CustomException;
import com.barclayscard.customercommand.aggregate.commands.AddCustomerCommand;

/**
 * class to validate age.
 * @author vtaktawa
 *
 */
public final class CustomerValidation {
	/**
	 * create a reference variable for util.
	 */
	private static CustomerValidation util = null;
	/**
	 * Age Eligibility.
	 */

	/**
	 * rule.eligibility.age.
	 */
	private static final  int ageEligibility = 16;

	/**
	 * No. arg constructor.
	 */
	private CustomerValidation() {
	}

	/**
	 * getinstance of util.
	 * @return Util.
	 */
	public static CustomerValidation getInstance() {
		if (util == null) {
			util = new CustomerValidation();
		}
		return util;
	}

	/**
	 * Valid adcustomer command.
	 * @param command
	 *            AddCustomerCommand.
	 * @throws CustomException
	 *             Custom Exception
	 */
	public  void valid(AddCustomerCommand command) throws CustomException {
		if (calculateAge(command.getDob()) <= ageEligibility) {
			throw new CustomException(" Data not saved : Age is less than or equal to 16 years.");
		}
	}

	/**
	 * Function to calculate the Age of Person.
	 * @param birthdate
	 *            Date of birth.
	 * @return Age
	 */
	static int calculateAge(Date birthdate) {
		Calendar birth = Calendar.getInstance();
		birth.setTime(birthdate);
		Calendar today = Calendar.getInstance();

		int yearDifference = today.get(Calendar.YEAR) - birth.get(Calendar.YEAR);

		if (today.get(Calendar.MONTH) < birth.get(Calendar.MONTH)) {
			yearDifference--;
		} else {

			if (today.get(Calendar.MONTH) == birth.get(Calendar.MONTH)
					&& today.get(Calendar.DAY_OF_MONTH) < birth.get(Calendar.DAY_OF_MONTH)) {
				yearDifference--;
			}

		}

		return yearDifference;
	}
}
