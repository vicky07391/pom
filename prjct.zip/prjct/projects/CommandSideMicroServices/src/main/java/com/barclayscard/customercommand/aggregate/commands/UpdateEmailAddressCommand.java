package com.barclayscard.customercommand.aggregate.commands;

import java.util.UUID;

import javax.validation.constraints.NotNull;
import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotBlank;

/**
 * command class for updating email address of customer.
 */
public class UpdateEmailAddressCommand {

  /** Target Identifier of Customer Aggregate. */
  @TargetAggregateIdentifier
  private final UUID id;

  /** Email Address. */
  @NotNull(message = "Email Address is mandatory")
  @NotBlank
  private final String emailAddress;

  /**
   * constructor with argument.
   * @param id
   *          Target Identifier.
   * @param emailAddress
   *          Email Address.
   */
  public UpdateEmailAddressCommand(UUID id, String emailAddress) {
    this.id = id;
    this.emailAddress = emailAddress;
  }

  /**
   * @return the id
   */
  public UUID getId() {
    return id;
  }

  /**
   * @return the emailAddress
   */
  public String getEmailAddress() {
    return emailAddress;
  }

}
