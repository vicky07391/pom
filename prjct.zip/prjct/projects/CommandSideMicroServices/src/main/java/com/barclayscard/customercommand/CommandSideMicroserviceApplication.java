package com.barclayscard.customercommand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Spring Boot Application class. */
@SpringBootApplication
public class CommandSideMicroserviceApplication {

  /**
   * Application Main Method.
   * @param args argument
   */
	public static void main(String[] args) {
		SpringApplication.run(CommandSideMicroserviceApplication.class, args);
	}
}
