package com.barclayscard.customer.exception;

import java.io.Serializable;

/**
 * throws Custom Exception.
 * @author Capgemini.
 *
 */
public class CustomException extends Exception implements Serializable {

	/**
	 * Default serialversionId.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * throws custom Exception.
	 * @param message
	 *            Custom Message.
	 */
	public CustomException(String message) {
		super(message);
	}

}
