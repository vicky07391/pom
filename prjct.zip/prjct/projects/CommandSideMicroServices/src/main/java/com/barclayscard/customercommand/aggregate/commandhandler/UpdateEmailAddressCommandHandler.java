package com.barclayscard.customercommand.aggregate.commandhandler;

import org.axonframework.commandhandling.annotation.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.barclayscard.customercommand.aggregate.CustomerAggregate;
import com.barclayscard.customercommand.aggregate.commands.UpdateEmailAddressCommand;

/** Command Handler for Updating Email Address. */
@Component
public class UpdateEmailAddressCommandHandler {

	/** Auto wired EventSourceRepository. */
	@Autowired
	private EventSourcingRepository<CustomerAggregate> customerEventSourcingRepository;

	/** Create LoggerFactory for UpdateAddressCommandHandler. */
	private static final Logger LOG = LoggerFactory.getLogger(UpdateEmailAddressCommandHandler.class);

	/**
	 * Method for UpdateEmailAddressCommandHandler.
	 * @param command
	 *            UpdateEmailAddressCommand.
	 */
	@CommandHandler
	public void updateEmailAddress(UpdateEmailAddressCommand command) {
		LOG.info("Command: 'UpdateEmailAddressCommand' received." + command.getEmailAddress());
		CustomerAggregate customerAggregate = (CustomerAggregate) customerEventSourcingRepository
					.load(command.getId());
		customerAggregate.updateEmailAddress(command.getEmailAddress());
	}

}
