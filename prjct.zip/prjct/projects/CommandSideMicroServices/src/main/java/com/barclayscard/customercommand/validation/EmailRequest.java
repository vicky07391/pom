package com.barclayscard.customercommand.validation;

import org.hibernate.validator.constraints.Email;

/**
 * email request parameter with validation annotation.
 * @author Capgemini
 *
 */
public class EmailRequest {

	/**
	 * Email Annotation for email validation.
	 */
	@Email
	private String email;

	/**
	 * return Email.
	 * @return Email email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * set the value of email.
	 * @param email Email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

}
