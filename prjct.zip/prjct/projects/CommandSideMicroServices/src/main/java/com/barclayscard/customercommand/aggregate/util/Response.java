package com.barclayscard.customercommand.aggregate.util;
/**
 * Response class for returning.
 * @author Capgemini.
 *
 */

public enum Response {
	/**
	 * Success enum.
	 */
    SUCCESS("Success occured : comamnd succesfully executed"),
    /**
	 * Failure enum.
	 */
    FAILURE("Error occured : comamnd not succesfully executed");

	/**
	 * returnCode ReturnCode.
	 */
    private String returnCode;

    /**
     * returnCode ReturnCode.
     * @param returnCode Return Code.
     */
    private Response(String returnCode) {
        this.returnCode = returnCode;
    }
    /**
  	 * returnCode ReturnCode.
  	 */
    public String getReturnCode() {
        return returnCode;
    }
}