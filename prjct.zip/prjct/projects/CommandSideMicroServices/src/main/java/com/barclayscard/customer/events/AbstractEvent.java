package com.barclayscard.customer.events;

import java.io.Serializable;
import java.util.UUID;

/**
 * . Base class for all events
 */

public abstract class AbstractEvent implements Serializable {
  private static final long serialVersionUID = 1L;

  /** Unique identifier for event. */
  private UUID id;

  /** Source identifier for event. */
  private String sourceIdentifier = "RABBITMQ TCP";

  /**
   * No argument constructor.
   */
  public AbstractEvent() {
  }

  /**
   * Argument Constructor.
   * @param id
   *          identifier
   */
  public AbstractEvent(UUID id) {
    this.id = id;
  }

  /**
   * Getter for identifier.
   * @return the id
   */
  public UUID getId() {
    return id;
  }

/**
 *  Getter for SourceIdentifier.
 * @return sourceIdentifier
 */
  public String getSourceIdentifier() {
	  return sourceIdentifier;
  }


}
