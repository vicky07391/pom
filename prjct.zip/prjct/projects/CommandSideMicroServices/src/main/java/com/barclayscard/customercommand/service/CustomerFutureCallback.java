package com.barclayscard.customercommand.service;

import org.axonframework.commandhandling.CommandCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * implemenatation of comamndCallback.
 * @author Capgemini
 *
 */
public class CustomerFutureCallback implements CommandCallback {

	/** Create a Logger Factory for DefaultAuditLogger. */
	private static final Logger LOG = LoggerFactory.getLogger(CustomerFutureCallback.class);

	/**
	 * Declare a response.
	 */
	private boolean response;

	/**
	 * On failure method.
	 */
	@Override
	public void onFailure(Throwable arg0) {
		// TODO Auto-generated method stub
		LOG.info("Error occured : command not succesfully executed" + arg0.getMessage());
		response = false;
	}

	/**
	 * on Success Method.
	 */
	@Override
	public void onSuccess(Object arg0) {
		// TODO Auto-generated method stub
		LOG.info("Command succesfully executed :" );
		response = true;
	}

	/**
	 * get a response .
	 * @return Response response.
	 */
	public  boolean isResponse() {
		return response;
	}

}
