package com.barclayscard.customercommand.service;

import com.barclayscard.customercommand.aggregate.util.Response;

/**
 * Application service interface class.
 * @author capgemini
 *
 */
public interface CommandService {
	/**
	 * command send method.
	 * @param command command
	 */
	Response send(Object command);
}
