package com.barclayscard.customercommand.aggregate.commands;

import java.util.UUID;

import javax.validation.constraints.NotNull;
import org.axonframework.commandhandling.annotation.TargetAggregateIdentifier;
import org.hibernate.validator.constraints.NotBlank;

/**
 * command class for updating mobile number of customer.
 */
public class UpdateMobileNumberCommand {

  /** Target Identifier of Customer Aggregate. */
  @TargetAggregateIdentifier
  private final UUID id;

  /** Mobile Number. */
  @NotNull(message = "Mobile Number is mandatory")
  @NotBlank
  private final String mobileNumber;

  /**
   * constructor with argument.
   * @param id
   *          Target Identifier
   * @param mobileNumber
   *          Mobile Number
   */
  public UpdateMobileNumberCommand(UUID id, String mobileNumber) {
    this.id = id;
    this.mobileNumber = mobileNumber;
  }

  /**
   * @return the id
   */
  public UUID getId() {
    return id;
  }

  /**
   * @return the mobileNumber
   */
  public String getMobileNumber() {
    return mobileNumber;
  }

}
