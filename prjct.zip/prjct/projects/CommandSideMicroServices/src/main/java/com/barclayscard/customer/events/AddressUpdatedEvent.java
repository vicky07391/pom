package com.barclayscard.customer.events;

import java.util.UUID;

import com.barclayscard.customer.valueobjects.Address;

/**
 * This is the event class for updating address of customer.
 */
public class AddressUpdatedEvent extends AbstractEvent {

	private static final long serialVersionUID = 1L;

	/** Address value object. */
	private Address address;

	/**
	 * No. arg constructor.
	 */
	public AddressUpdatedEvent() {
	}

	/**
	 * Agrument Contructor.
	 * @param id
	 *            identifier for event
	 * @param address
	 *            value object
	 */
	public AddressUpdatedEvent(UUID id, Address address) {
		super(id);
		this.address = address;
	}

	/**
	 * Get method for Address.
	 * @return Address address
	 */
	public Address getAddress() {
		return address;
	}

}
