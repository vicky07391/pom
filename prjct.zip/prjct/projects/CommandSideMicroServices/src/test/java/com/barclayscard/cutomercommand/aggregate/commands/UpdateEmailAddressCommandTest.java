
package com.barclayscard.cutomercommand.aggregate.commands;
import java.util.Date;
import org.axonframework.test.FixtureConfiguration;
import org.axonframework.test.Fixtures;
import org.junit.Before;
import org.junit.Test;
import com.barclayscard.customer.events.CustomerAddedEvent;
import com.barclayscard.customer.events.EmailAddressUpdatedEvent;
import com.barclayscard.customer.valueobjects.Address;
import com.barclayscard.customercommand.aggregate.CustomerAggregate;
import com.barclayscard.customercommand.aggregate.commandhandler.UpdateEmailAddressCommandHandler;
import com.barclayscard.customercommand.aggregate.commands.UpdateEmailAddressCommand;


/**
 * @author Capgemini
 *
 */
public class UpdateEmailAddressCommandTest {
	/**
	 * Fixture configuration.
	 */
/*	private FixtureConfiguration fixture;

	*//**
	 * Set up for command test execution.
	 *//*
	@Before
	public void setUp() {
		fixture = Fixtures.newGivenWhenThenFixture(CustomerAggregate.class);
		if (fixture.getRepository() == null) {
			System.out.println("Repository is NULL");
		}
		final UpdateEmailAddressCommandHandler updateEmailAddressCommandHandler = new UpdateEmailAddressCommandHandler();
		fixture.registerAnnotatedCommandHandler(updateEmailAddressCommandHandler);
	}

	*//**
	 * Test for update email address.
	 *//*
	@Test
	public void testFirstFixture() {
		final String oldEmailAddress = "prabhakar@capgemini.com";
		final String newEmailAddress = "def@xyz.com";
		final Address address = new Address("SunGreen Heights", "Woodcross Rod", "411038");
		fixture.given(new CustomerAddedEvent("e02bc32b-3aba-4701-b517-15325d4883bc", "Albert", "Piter", "9970685561",
				oldEmailAddress, address, new Date()))
				.when(new UpdateEmailAddressCommand("e02bc32b-3aba-4701-b517-15325d4883bc", newEmailAddress))
				.expectVoidReturnType().expectEvents(new EmailAddressUpdatedEvent());
	}*/
}
