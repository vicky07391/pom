package com.barclayscard.customerquery.domain.customer.repository;

import java.util.UUID;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.barclayscard.customerquery.domain.customer.Customer;

/**
 * .
 */
@RepositoryRestResource(collectionResourceRel = "customers", path = "customers")
public interface CustomerRepository extends MongoRepository<Customer, UUID> {
/**
* finds the customer from DB on behalf of id.
* @param id identifier
* @return Customer
*/
	Customer findById(UUID id);
}
