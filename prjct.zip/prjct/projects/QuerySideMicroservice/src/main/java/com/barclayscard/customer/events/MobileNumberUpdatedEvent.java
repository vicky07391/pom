package com.barclayscard.customer.events;

import java.util.UUID;

/**
 * MobileNumberUpdatedEvent is an event class for Mobile Number updating of
 * customer.
 */
public class MobileNumberUpdatedEvent extends AbstractEvent {

	private static final long serialVersionUID = 1L;
	/**
	 * Mobile Number field of customer.
	 */
	private String mobileNumber;

	/** No Argument Constructor. */
	public MobileNumberUpdatedEvent() {
	}

	/**
	 * Argument Constructor.
	 * @param id
	 *            identifier
	 * @param mobileNumber
	 *            Mobile Number
	 */
	public MobileNumberUpdatedEvent(UUID id, String mobileNumber) {
		super(id);
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}
}
