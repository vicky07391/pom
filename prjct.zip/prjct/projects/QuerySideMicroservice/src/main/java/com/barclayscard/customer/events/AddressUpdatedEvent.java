package com.barclayscard.customer.events;

import java.util.UUID;

import com.barclayscard.customer.valueobjects.Address;

/**
 * AddressUpdatedEvent is an event class for Address updating of customer.
 */
public class AddressUpdatedEvent extends AbstractEvent {
	private static final long serialVersionUID = 1L;
	/**
	 * Address field of customer.
	 */
	private Address address;

	/**
	 * Argument Constructor.
	 * @param id
	 *            identifier
	 * @param address
	 *            Address
	 */
	public AddressUpdatedEvent(UUID id, Address address) {
		super(id);
		this.address = address;
	}

	/** No Argument Constructor. */
	public AddressUpdatedEvent() {
	}

	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

}
