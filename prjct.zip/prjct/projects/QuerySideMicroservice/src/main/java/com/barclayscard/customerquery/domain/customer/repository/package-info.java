/**
 * 
 */
/**
 * @author Capgemini
 *
 */
package com.barclayscard.customerquery.domain.customer.repository;