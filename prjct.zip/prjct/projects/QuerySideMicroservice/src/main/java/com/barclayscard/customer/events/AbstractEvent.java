package com.barclayscard.customer.events;

import java.io.Serializable;
import java.util.UUID;

/**
 * AbstractEvent is for unique event id.
 */
public abstract class AbstractEvent implements Serializable {
	private static final long serialVersionUID = 1L;
	/** Unique identifier for events. */
	private UUID id;

	 /** Source identifier for event. */
	 private String sourceIdentifier = "RABBITMQ TCP";

	/** No Argument Constructor. */
	public AbstractEvent() {
	}

	/**
	 * Argument Constructor.
	 * @param id identifier
	 */
	public AbstractEvent(UUID id) {
		this.id = id;
	}

	/**
	 * @return the id
	 */
	public UUID getId() {
		return id;
	}

	/**
	 *  Getter for SourceIdentifier.
	 * @return sourceIdentifier
	 */
	  public String getSourceIdentifier() {
		  return sourceIdentifier;
	  }

}
