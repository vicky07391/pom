package com.barclayscard.customerquery.configuration;

import org.axonframework.contextsupport.spring.AnnotationDriven;
import org.axonframework.eventhandling.ClusteringEventBus;
import org.axonframework.eventhandling.DefaultClusterSelector;
import org.axonframework.eventhandling.EventBus;
import org.axonframework.eventhandling.EventBusTerminal;
import org.axonframework.eventhandling.SimpleCluster;
import org.axonframework.eventhandling.amqp.spring.ListenerContainerLifecycleManager;
import org.axonframework.eventhandling.amqp.spring.SpringAMQPConsumerConfiguration;
import org.axonframework.eventhandling.amqp.spring.SpringAMQPTerminal;
import org.axonframework.serializer.json.JacksonSerializer;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.transaction.RabbitTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import com.barclayscard.customerquery.domain.customer.handler.CustomerViewEventHandler;
import com.mongodb.MongoClient;

/**
 * Axon Configuration for CQRS Application.
 *
 */
@Configuration
@AnnotationDriven
@ComponentScan("com.barclayscard")
public class AxonConfiguration {
	/** amqp config key for Queue. */
	private static final String AMQP_CONFIG_KEY = "AMQP.Config";

	/** auto wire the bean of connectionfactory of queue. */
	@Autowired
	@Qualifier("connectionFactory")
	private ConnectionFactory connectionFactory;

	/** Spring amqp tx size. */
	@Value("${springamqp.txtsize}")
	private int textSize;

	/** MongoDB Host name. */
	@Value("${spring.data.mongodb.host}")
	private String host;
	/** MongoDB Database name. */
	@Value("${spring.data.mongodb.database}")
	private String mongoDB;

	/** auto wire the bean of transactionManager of queue. */
	@Autowired
	private RabbitTransactionManager transactionManager;
	/**
	 * The actual value expression of queue :
	 * {applicationProperties.spring.application.queue.
	 */

	@Value("${spring.application.queue}")
	private String queueName;

	/**
	 * The actual value expression of exchange :
	 * {applicationProperties.spring.application.exchange.
	 */
	@Value("${spring.application.exchange}")
	private String exchangeName;

	/**
	 * Serializer implementation that uses Jackson to serialize objects into a
	 * JSON format.
	 * @return JacksonSerializer.
	 */
	@Bean
	JacksonSerializer axonJsonSerializer() {
		return new JacksonSerializer();
	}

	/**
	 * Manages the lifecycle of the SimpleMessageListenerContainers that have
	 * been created to receive messages for Clusters. The
	 * ListenerContainerLifecycleManager starts each of the Listener Containers
	 * when the context is started and will stop each of them when the context
	 * is being shut down.
	 * @return ListenerContainerLifecycleManager
	 */
	@Bean
	ListenerContainerLifecycleManager listenerContainerLifecycleManager() {
		ListenerContainerLifecycleManager mgr = new ListenerContainerLifecycleManager();
		mgr.setConnectionFactory(connectionFactory);
		return mgr;
	}

	/**
	 * This bean allows configuration using setters, to make it easier to
	 * configure inside an application context configuration file.
	 * @return SpringAMQPConsumerConfiguration
	 */
	@Bean
	SpringAMQPConsumerConfiguration springAMQPConsumerConfiguration() {
		SpringAMQPConsumerConfiguration cfg = new SpringAMQPConsumerConfiguration();
		cfg.setTransactionManager(transactionManager);
		cfg.setQueueName(queueName);
		cfg.setTxSize(textSize);
		return cfg;
	}

	/**
	 * A simple Cluster implementation that invokes each of the members of a
	 * cluster when an Event is published.
	 * @return SimpleCluster
	 */
	@Bean
	SimpleCluster simpleCluster() {
		SimpleCluster cluster = new SimpleCluster(queueName);
		cluster.getMetaData().setProperty(AMQP_CONFIG_KEY, springAMQPConsumerConfiguration());
		return cluster;
	}

	/**
	 * Interface describing a mechanism that connects Event Bus clusters. The
	 * terminal is responsible for delivering published Events with all of the
	 * clusters available in the Event Bus.
	 * @return EventBusTerminal
	 */
	@Bean
	EventBusTerminal terminal() {
		SpringAMQPTerminal terminal = new SpringAMQPTerminal();
		terminal.setConnectionFactory(connectionFactory);
		terminal.setExchangeName(exchangeName);
		terminal.setDurable(true);
		terminal.setTransactional(true);
		terminal.setSerializer(axonJsonSerializer());
		// terminal.setSerializer(xmlSerializer());
		terminal.setListenerContainerLifecycleManager(listenerContainerLifecycleManager());
		return terminal;
	}

	/**
	 * The EventBus is the mechanism that dispatches events to the subscribed
	 * event listeners.
	 * @return EventBus
	 */
	@Bean
	EventBus eventBus() {
		return new ClusteringEventBus(new DefaultClusterSelector(simpleCluster()), terminal());
	}

	/**
	 * The MongoTemplate is the mechanism that connects to MongoDB.
	 * @return MongoTemplate
	 * @throws Exception exception
	 */
	@Bean
	public MongoTemplate mongoTemplate() throws Exception {
		return new MongoTemplate(new MongoClient(host), mongoDB);
	}

	/**
	 * CustomerViewEventHandler bean creation.
	 * @return customerViewEventHandler
	 */
	@Bean
	public CustomerViewEventHandler customerViewEventHandler() {
		CustomerViewEventHandler customerViewEventHandler = new CustomerViewEventHandler();
		return customerViewEventHandler;
	}

}
