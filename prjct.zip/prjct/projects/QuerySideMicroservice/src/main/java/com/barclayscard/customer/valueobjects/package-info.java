/**
 * @author Capgemini
 *
 */
package com.barclayscard.customer.valueobjects;