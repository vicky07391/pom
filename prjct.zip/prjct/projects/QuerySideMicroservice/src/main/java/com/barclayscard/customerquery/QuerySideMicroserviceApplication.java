package com.barclayscard.customerquery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This is the starting class for QuerySideMicroserviceApplication.
 */
@SpringBootApplication
public class QuerySideMicroserviceApplication {
	/**
	 * run method for QuerySideMicroserviceApplication from where the application getting starts .
	 * @param args default args
	 */
	public static void main(String[] args) {
		SpringApplication.run(QuerySideMicroserviceApplication.class, args);
	}
}
