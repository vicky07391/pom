/**
 * @author Capgemini
 */
package com.card.constant;

/**
 * @author Capgemini
 */
public final class Constants {
    /** Default private. */
    private Constants() {
    }

    /** Represents timer URL. */
    public static final String TIMER = "timer://event?fixedRate=true&period=30s";
    /** Represents destination name TCP. */
    public static final String DESTINATION_NAME_TCP = "TCP";
    /** Represents destination name JMS. */
    public static final String DESTINATION_NAME_JMS = "jms";
    /** Represents mapping file name. */
    public static final String DOZER_MAPPING_FILE = "mapping.xml";
    /** Represents source destination file element tag name. */
    public static final String ELEMENT_TAG_NAME = "Transaction";
    /** Represents source destination file element tag name. */
    public static final String ELEMENT_TAG_NAME_PROTOCOL = "protocol";
    /** Represents source destination file element tag name. */
    public static final String ELEMENT_TAG_NAME_PORT = "port";
    /** Represents source destination file element tag name. */
    public static final String ELEMENT_TAG_NAME_DESTIP = "destinationIP";
    /** Represents source destination file element tag name. */
    public static final String ELEMENT_TAG_NAME_SOURCE = "source";
    /** Represents source destination file name. */
    public static final String SOURCE_DESTINATION_FILE_NAME = "source-destination.xml";
    /** Represents Success Message code. */
    public static final int SUCCESS_MESSAGE_LENGTH = 7;
    /** Represents Error Message offset/start . */
    public static final int ERROR_MESSAGE_START = 7;
    /** Represents Error Message code length . */
    public static final int ERROR_MESSAGE_END = 11;
    /** Represents source identifier code length . */
    public static final int SOURCE_IDENTIFIER_MESSAGE_START = 11;
    /** Represents source identifier Message code length . */
    public static final int SOURCE_IDENTIFIER_MESSAGE_END = 26;
    /** Represents correlation ID Message code length . */
    public static final int CORRELATION_ID_MESSAGE_START = 26;
    /** Represents correlation ID Message code length . */
    public static final int CORRELATION_ID_MESSAGE_END = 62;
    /** Represents eventType Message code length . */
    public static final int EVENT_TYPE_MESSAGE_START = 62;
    /** Represents correlation ID Message code length . */
    public static final int EVENT_TYPE_MESSAGE_END = 190;
    /** Represents response content type. */
    public static final String RESPONSE_CONTENT_TYPE ="application/json";
}
