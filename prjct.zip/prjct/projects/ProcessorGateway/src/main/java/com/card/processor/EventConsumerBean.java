package com.card.processor;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.card.destination.model.CustomerDestination;
import com.card.dozer.DozerMapping;
import com.card.source.model.Customer;
@Component
public final class EventConsumerBean {

    /** Logger. */
    private static final Logger logger = LoggerFactory.getLogger(EventConsumerBean.class);
    /** dozerMapping initialization. */
    @Autowired
    private DozerMapping dozerMapping;
    @Autowired
    private CustomerDestination customerDestination;
    @Autowired
    private Customer customerSource;
    /** Method returns the destination customer object.
     * 
     * @param exchange message in exchange
     * @throws Exception exception thrown */
    public void consumerProcess(Exchange exchange){
        logger.info("In EventConsumerBean Processor....");
        try {
            if (!StringUtils.isEmpty(exchange)) {
                Object object = exchange.getIn().getBody();
                if (!StringUtils.isEmpty(object) && object instanceof Customer) {
                    customerSource = (Customer) object;
                    if (!StringUtils.isEmpty(customerSource.getCorrelationID())) {
                        customerDestination = dozerMapping.mappedObject(customerSource);
                        if (!StringUtils.isEmpty(customerDestination)) {
                            logger.info("Sending exchange after mapping is:" + customerDestination.toString().length());
                            exchange.getOut().setBody(customerDestination.toString() + "\r\n");
                        } else {
                            exchange.getOut().setBody(null);
                            logger.info("Mapped customer destination object is null or empty");
                        }
                    } else {
                        exchange.getOut().setBody(null);
                        logger.info("The UUID is null or empty");
                    }
                } else {
                    exchange.getOut().setBody(null);
                    logger.info("Exchange is empty or null");
                }
            }
        } catch (Exception e) {
            logger.info("Exception in processing exchange.");
        }
    }

}
