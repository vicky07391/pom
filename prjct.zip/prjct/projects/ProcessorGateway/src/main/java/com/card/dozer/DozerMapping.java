package com.card.dozer;

import org.dozer.DozerBeanMapper;
import org.dozer.MappingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.card.destination.model.CustomerDestination;
import com.card.destination.model.DestinationAckModel;
import com.card.source.model.Customer;
import com.card.source.model.Response;
/** Mapping class to map source object to Destination object. */
@Component
public class DozerMapping {

    /** Logger. */
    private static final Logger logger = LoggerFactory.getLogger(DozerMapping.class);
    @Autowired
    private DozerBeanMapper dozerBean;
    /** Method produce mapped object of CustomerDestination.
     * 
     * @param customer object
     * @return customerDestination object */
    public CustomerDestination mappedObject(Customer customer) {
        try {
            CustomerDestination customerDestination = dozerBean.map(customer, CustomerDestination.class);
            logger.info("Mapped object is:" + customerDestination);
            return customerDestination;
        } catch (MappingException e) {
            logger.info("Exception in mapping customer data:" + e.getMessage());
            return null;
        }
    }
    /** Method produce mapped object of Response.
     * 
     * @param responseFromDestination destination response object
     * @return customerResponse object */
    public Response mappedObject(DestinationAckModel responseFromDestination) {
        try {
            Response response = dozerBean.map(responseFromDestination, Response.class);
            logger.info("Mapped object is:" + response);
            return response;
        } catch (MappingException e) {
            logger.info("Exception in mapping response data:" + e.getMessage());
            return null;
        }
    }
}
