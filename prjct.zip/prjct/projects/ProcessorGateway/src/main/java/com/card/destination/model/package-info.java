/**
 * @author Capgemini
 *
 */
package com.card.destination.model;
