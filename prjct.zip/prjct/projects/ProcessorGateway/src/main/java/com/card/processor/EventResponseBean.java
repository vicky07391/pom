package com.card.processor;

import java.io.UnsupportedEncodingException;
import java.util.UUID;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import com.card.constant.Constants;
import com.card.destination.model.DestinationAckModel;
import com.card.dozer.DozerMapping;
import com.card.source.model.Response;

public class EventResponseBean {
    /** Logger. */
    private static final Logger logger = LoggerFactory.getLogger(EventResponseBean.class);
    /** dozerMapping initialization. */
    @Autowired
    private DozerMapping dozerMapping;
    /** Initialization of ResponseFromDestination class. */
    @Autowired
    private DestinationAckModel responseFromDestination;
    /** Method returns the destination customer object.
     * @param exchange message in exchange
     * @throws Exception exception thrown */
    public void producerProcess(Exchange exchange) {
        logger.info("In EventResponseBean Processor....");
        try {
            if (!StringUtils.isEmpty(exchange) && !StringUtils.isEmpty(exchange.getIn().getBody())) {
                String responseData = null;
                if ((exchange.getIn().getBody()) instanceof String) {
                    responseData = exchange.getIn().getBody().toString();
                } else if ((exchange.getIn().getBody()) instanceof byte[]) {
                    responseData = new String((byte[]) exchange.getIn().getBody(), "UTF-8");
                } else {
                    logger.info("Response data is in different format.");
                }
                if (!StringUtils.isEmpty(responseData) && !StringUtils.isEmpty(responseData)) {
                    logger.info("Response Data:" + responseData);
                    responseFromDestination.setSuccessMessage(responseData.substring(0,
                            Constants.SUCCESS_MESSAGE_LENGTH));
                    responseFromDestination.setErrorCode(responseData.substring(Constants.ERROR_MESSAGE_START,
                            Constants.ERROR_MESSAGE_END));
                    responseFromDestination.setSourceIdentifier(responseData.substring(
                            Constants.SOURCE_IDENTIFIER_MESSAGE_START, Constants.SOURCE_IDENTIFIER_MESSAGE_END));
                    responseFromDestination.setCorrelationID(UUID.fromString(responseData.substring(
                            Constants.CORRELATION_ID_MESSAGE_START, Constants.CORRELATION_ID_MESSAGE_END)));
                    responseFromDestination.setEventType(responseData.substring(Constants.EVENT_TYPE_MESSAGE_START,
                            Constants.EVENT_TYPE_MESSAGE_END));
                    Response response = dozerMapping.mappedObject(responseFromDestination);
                    if (!StringUtils.isEmpty(response)) {
                        exchange.getOut().setBody(response);
                    } else {
                        logger.info("Mapped response is null or empty");
                    }
                } else {
                    logger.info("Response Message is null or empty");
                }
            } else {
                logger.info("Excange or body is empty or null");
            }
        } catch (UnsupportedEncodingException e) {
            logger.info("Unsupported encoding for response message.\n" + e.getMessage());
        } catch (Exception e) {
            logger.info("Exception in processing response exchange.\n" + e.getMessage());
        }
    }
}
