package com.card.source.model;

import java.io.Serializable;
import java.util.UUID;

import org.springframework.stereotype.Component;
/** Customer response POJO class. */
@Component
public class Response implements Serializable {
    /** Serialization default ID. */
    private static final long serialVersionUID = 1L;
    /** Response Success Message. */
    private String successMessage;
    /** Response Error code. */
    private String errorCode;
    /** Source Identifier. */
    private String sourceIdentifier;
    /** Correlation ID. */
    private UUID correlationID;
    /** Response eventType. */
    private String eventType;

    /** @return the errorCode. */
    public String getErrorCode() {
        return errorCode;
    }
    /** @param errorCode the errorCode to set. */
    public void setErrorCode(String errorCode) {
        this.errorCode = String.format("%1$" + 4 + "s", errorCode);
    }
    /** @return the successMessage. */
    public String getSuccessMessage() {
        return successMessage;
    }
    /** @param successMessage the successMessage to set. */
    public void setSuccessMessage(String successMessage) {
        this.successMessage = String.format("%1$" + 7 + "s", successMessage);
    }
    /** @return the sourceIdentifier. */
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }
    /** @param sourceIdentifier the sourceIdentifier to set. */
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = String.format("%1$" + 15 + "s", sourceIdentifier);
    }
    /** @return the correlationID. */
    public UUID getCorrelationID() {

        return correlationID;
    }
    /** @param correlationID the correlationID to set. */
    public void setCorrelationID(UUID correlationID) {

        this.correlationID = correlationID;
    }
    /** @return the eventType */
    public String getEventType() {
        return eventType;
    }
    /** @param eventType the eventType to set */
    public void setEventType(String eventType) {
        this.eventType = String.format("%1$" + 128 + "s", eventType);
    }
    /** @param errorCode response error code.
     * @param successMessage response success message
     * @param sourceIdentifier source identification ID
     * @param correlationID correlation ID */
    public Response(String errorCode, String successMessage, String sourceIdentifier, UUID correlationID,
            String eventType) {
        super();
        this.errorCode = errorCode;
        this.successMessage = successMessage;
        this.sourceIdentifier = sourceIdentifier;
        this.correlationID = correlationID;
        this.eventType = eventType;
    }
    /** Default Constructor. */
    public Response() {

    }
    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return successMessage + "" + errorCode + "" + sourceIdentifier + "" + correlationID + "" + eventType;
    }

}
