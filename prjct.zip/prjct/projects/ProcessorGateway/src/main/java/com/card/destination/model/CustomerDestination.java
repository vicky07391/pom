package com.card.destination.model;

import java.io.Serializable;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

/** POJO class for mapping incoming JSON request for Customer. */
@Component
public class CustomerDestination implements Serializable {

    /** Serial version default ID. */
    private static final long serialVersionUID = 1L;
    /** firstName. */
    private String firstName;
    /** lastName. */
    private String lastName;
    /** mobileNumber. */
    private String mobileNumber;
    /** emailAddress. */
    private String emailAddress;
    /** dob. */
    private String dob;
    /** buildingName. */
    private String buildingName;
    /** streetName. */
    private String streetName;
    /** postalCode. */
    private String postalCode;
    /** Source Identifier. */
    private String sourceIdentifier;
    /** Correlation ID. */
    @JsonProperty("id") 
    private UUID correlationID;
    /** Customer eventType. */
    private String eventType;

    /** @return the firstName. */
    public String getFirstName() {
        return String.format("%1$" + 25 + "s", Optional.ofNullable(firstName).orElse(""));
    }
    /** @param firstName the firstName to set. */
    public void setFirstName(String firstName) {
        this.firstName = String.format("%1$" + 25 + "s", Optional.ofNullable(firstName).orElse(""));
    }
    /** @return the lastName. */
    public String getLastName() {
        return String.format("%1$" + 25 + "s", Optional.ofNullable(lastName).orElse(""));
    }
    /** @param lastName the lastName to set. */
    public void setLastName(String lastName) {
        this.lastName = String.format("%1$" + 25 + "s", Optional.ofNullable(lastName).orElse(""));
    }
    /** @return the mobileNumber. */
    public String getMobileNumber() {
        return String.format("%1$" + 14 + "s", Optional.ofNullable(mobileNumber).orElse(""));
    }
    /** @param mobileNumber the mobileNumber to set. */
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = String.format("%1$" + 14 + "s", Optional.ofNullable(mobileNumber).orElse(""));
    }
    /** @return the emailAddress. */
    public String getEmailAddress() {
        return String.format("%1$" + 128 + "s", Optional.ofNullable(emailAddress).orElse(""));
    }
    /** @param emailAddress the emailAddress to set. */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = String.format("%1$" + 128 + "s", Optional.ofNullable(emailAddress).orElse(""));
    }
    /** @return the dob. */
    public String getDob() {
        return String.format("%1$" + 10 + "s", Optional.ofNullable(dob).orElse(""));
    }
    /** @param dob the dob to set. */
    public void setDob(String dob) {
        this.dob = String.format("%1$" + 10 + "s", Optional.ofNullable(dob).orElse(""));
    }
    /** @return the buildingName. */
    public String getBuildingName() {
        return String.format("%1$" + 30 + "s", Optional.ofNullable(buildingName).orElse(""));
    }
    /** @param buildingName the buildingName to set. */
    public void setBuildingName(String buildingName) {
        this.buildingName = String.format("%1$" + 30 + "s", Optional.ofNullable(buildingName).orElse(""));
    }
    /** @return the streetName. */
    public String getStreetName() {
        return String.format("%1$" + 25 + "s", Optional.ofNullable(streetName).orElse(""));
    }
    /** @param streetName the streetName to set. */
    public void setStreetName(String streetName) {
        this.streetName = String.format("%1$" + 25 + "s", Optional.ofNullable(streetName).orElse(""));
    }
    /** @return the postalCode. */
    public String getPostalCode() {
        return String.format("%1$" + 8 + "s", Optional.ofNullable(postalCode).orElse(""));
    }
    /** @param postalCode the postalCode to set. */
    public void setPostalCode(String postalCode) {
        this.postalCode = String.format("%1$" + 8 + "s", Optional.ofNullable(postalCode).orElse(""));
    }
    /** @return the sourceIdentifier. */
    public String getSourceIdentifier() {
        return String.format("%1$" + 15 + "s", Optional.ofNullable(sourceIdentifier).orElse(""));
    }
    /** @param sourceIdentifier the sourceIdentifier to set. */
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = String.format("%1$" + 15 + "s", Optional.ofNullable(sourceIdentifier).orElse(""));
    }
    /** @return the correlationID. */
    public UUID getCorrelationID() {
        return correlationID;
    }
    /** @param correlationID the correlationID to set. */
    public void setCorrelationID(UUID correlationID) {

        this.correlationID = correlationID;
    }

    /** @return the eventType */
    public String getEventType() {
        return String.format("%1$" + 128 + "s", Optional.ofNullable(eventType).orElse(""));
    }
    /** @param eventType the eventType to set */
    public void setEventType(String eventType) {
        this.eventType = String.format("%1$" + 128 + "s", Optional.ofNullable(eventType).orElse(""));
    }
    /** @param firstName customer firstName.
     * @param lastName customer lastName
     * @param mobileNumber customer mobile
     * @param emailAddress customer email
     * @param dob customer DOB
     * @param buildingName Address buildingName
     * @param streetName Address streetName
     * @param postalCode Address postalCode
     * @param sourceIdentifier Source Identification ID
     * @param correlationID Correlation ID */
    public CustomerDestination(String firstName, String lastName, String mobileNumber, String emailAddress, String dob,
            String buildingName, String streetName, String postalCode, String sourceIdentifier, UUID correlationID,
            String eventType) {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.mobileNumber = mobileNumber;
        this.emailAddress = emailAddress;
        this.dob = dob;
        this.buildingName = buildingName;
        this.streetName = streetName;
        this.postalCode = postalCode;
        this.sourceIdentifier = sourceIdentifier;
        this.correlationID = correlationID;
        this.eventType = eventType;
    }
    /** Default Constructor. */
    public CustomerDestination() {
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return correlationID + "" + firstName + "" + lastName + "" + mobileNumber + "" + emailAddress + "" + dob + ""
                + buildingName + "" + streetName + "" + postalCode + "" + sourceIdentifier + "" + eventType;
    }

}
