package com.card.application;

import java.util.Arrays;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;

import com.card.constant.Constants;

/** @author ldudhbha */

@SpringBootApplication
@EnableAutoConfiguration
@ImportResource("classpath:camel-context.xml")
@ComponentScan({ "com.card", "com.card.processor", "com.card.dozer"})
public class GatewayApplication {
    /** Main Method.
     * 
     * @param args string array.
     * @throws Exception exception thrown. */
    public static void main(String[] args) throws Exception {
        SpringApplication.run(GatewayApplication.class, args);
    }
    /** @return dozerBean */
    @Bean(name = "org.dozer.Mapper")
    public DozerBeanMapper dozerBean() {
        List<String> mappingFiles = Arrays.asList(Constants.DOZER_MAPPING_FILE);
        DozerBeanMapper dozerBean = new DozerBeanMapper();
        dozerBean.setMappingFiles(mappingFiles);
        return dozerBean;
    }

}
